import React, { useCallback, useRef, useState, ChangeEvent } from 'react';
import Webcam from 'react-webcam';
import { Camera as CameraIcon, Upload, Send } from 'lucide-react';

interface CameraProps {
  onCapture: (imageSrc: string) => void;
  onTextSubmit: (text: string) => void;
}

export const Camera: React.FC<CameraProps> = ({ onCapture, onTextSubmit }) => {
  const webcamRef = useRef<Webcam>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showCamera, setShowCamera] = useState(true);
  const [foodDescription, setFoodDescription] = useState('');

  const capture = useCallback(() => {
    const imageSrc = webcamRef.current?.getScreenshot();
    if (imageSrc) {
      onCapture(imageSrc);
      setShowCamera(false);
    }
  }, [onCapture]);

  const handleFileUpload = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        onCapture(base64String);
        setShowCamera(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleTextSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (foodDescription.trim()) {
      onTextSubmit(foodDescription.trim());
      setShowCamera(false);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  if (!showCamera) {
    return null;
  }

  return (
    <div className="w-full max-w-md mx-auto space-y-8">
      <div className="relative">
        <Webcam
          audio={false}
          ref={webcamRef}
          screenshotFormat="image/jpeg"
          className="w-full rounded-lg shadow-lg"
          videoConstraints={{
            facingMode: { exact: "environment" }
          }}
        />
        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-4">
          <button
            onClick={capture}
            className="bg-blue-500 text-white p-4 rounded-full hover:bg-blue-600 transition-colors"
            title="Take photo"
          >
            <CameraIcon className="w-6 h-6" />
          </button>
          <button
            onClick={triggerFileInput}
            className="bg-green-500 text-white p-4 rounded-full hover:bg-green-600 transition-colors"
            title="Upload image"
          >
            <Upload className="w-6 h-6" />
          </button>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-lg">
        <h3 className="text-lg font-semibold mb-4">Or describe your food</h3>
        <form onSubmit={handleTextSubmit} className="space-y-4">
          <textarea
            value={foodDescription}
            onChange={(e) => setFoodDescription(e.target.value)}
            placeholder="Describe the food you want to analyze (e.g., 'Grilled salmon with quinoa and steamed vegetables')"
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 min-h-[100px]"
          />
          <button
            type="submit"
            disabled={!foodDescription.trim()}
            className="w-full bg-blue-500 text-white py-3 px-4 rounded-lg hover:bg-blue-600 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            <Send className="w-5 h-5" />
            Analyze Description
          </button>
        </form>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileUpload}
        className="hidden"
      />
    </div>
  );
};