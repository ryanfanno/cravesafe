import React from 'react';
import { FoodAnalysis } from '../types';
import { NutritionChart } from './NutritionChart';
import { AlertTriangle, CheckCircle, AlertCircle } from 'lucide-react';

interface AnalysisProps {
  analysis: FoodAnalysis | null;
  imageSrc?: string;
}

export const Analysis: React.FC<AnalysisProps> = ({ analysis, imageSrc }) => {
  if (!analysis) return null;

  const getSafetyColor = (score: number) => {
    if (score >= 80) return 'text-green-500';
    if (score >= 50) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getAllergenList = () => {
    const allergens = [];
    if (analysis.allergenInfo.containsGluten) allergens.push('Gluten');
    if (analysis.allergenInfo.containsPeanuts) allergens.push('Peanuts');
    if (analysis.allergenInfo.containsTreeNuts) allergens.push('Tree Nuts');
    if (analysis.allergenInfo.containsDairy) allergens.push('Dairy');
    if (analysis.allergenInfo.containsEggs) allergens.push('Eggs');
    if (analysis.allergenInfo.containsSoy) allergens.push('Soy');
    if (analysis.allergenInfo.containsShellfish) allergens.push('Shellfish');
    if (analysis.allergenInfo.containsFish) allergens.push('Fish');
    return allergens;
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 md:p-6 max-w-2xl mx-auto mt-8">
      <div className="flex flex-col md:flex-row md:items-start gap-4 md:gap-6 mb-6">
        {imageSrc && (
          <div className="w-full md:w-1/3 min-w-[200px]">
            <img 
              src={imageSrc} 
              alt={analysis.foodType}
              className="w-full h-auto rounded-lg shadow-sm object-cover"
            />
          </div>
        )}
        <div className="flex-1">
          <h2 className="text-2xl font-bold mb-2">{analysis.foodType}</h2>
          
          <div className="mb-4">
            <h3 className="text-lg font-semibold mb-2">Key Information:</h3>
            <ul className="list-disc list-inside space-y-1 text-gray-600">
              <li>Contains: {analysis.ingredients.slice(0, 3).join(', ')}{analysis.ingredients.length > 3 ? ', ...' : ''}</li>
              <li>Calories: {analysis.macronutrients.calories} kcal per serving</li>
              {analysis.preservatives.length > 0 && (
                <li>Contains preservatives: {analysis.preservatives.join(', ')}</li>
              )}
            </ul>
          </div>

          <div className="mb-4">
            <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
              <AlertCircle className="text-red-500 w-5 h-5" />
              Allergy Information
            </h3>
            <div className="bg-red-50 border border-red-100 rounded-lg p-4">
              {getAllergenList().length > 0 ? (
                <>
                  <p className="font-semibold text-red-700 mb-2">Contains the following allergens:</p>
                  <ul className="list-disc list-inside space-y-1 text-red-600">
                    {getAllergenList().map((allergen, index) => (
                      <li key={index}>{allergen}</li>
                    ))}
                    {analysis.allergenInfo.otherAllergens.map((allergen, index) => (
                      <li key={`other-${index}`}>{allergen}</li>
                    ))}
                  </ul>
                </>
              ) : (
                <p className="text-green-700">No common allergens detected</p>
              )}
              {analysis.allergenNotes && (
                <div className="mt-2 text-red-600 text-sm">
                  <p className="font-semibold">Additional Notes:</p>
                  <p>{analysis.allergenNotes}</p>
                </div>
              )}
            </div>
          </div>
          
          <div className="mb-4">
            <h3 className="text-lg font-semibold mb-2">Pregnancy Safety Score</h3>
            <div className={`text-4xl font-bold ${getSafetyColor(analysis.pregnancySafetyScore)}`}>
              {analysis.pregnancySafetyScore}/100
            </div>
            <div className="mt-2">
              <div className="flex items-start gap-2">
                {analysis.pregnancySafetyScore >= 70 ? (
                  <CheckCircle className="text-green-500 mt-1 flex-shrink-0" />
                ) : (
                  <AlertTriangle className="text-yellow-500 mt-1 flex-shrink-0" />
                )}
                <ul className="list-disc list-inside space-y-1">
                  {analysis.pregnancySafetyNotes.split('. ').map((note, index) => (
                    <li key={index} className="text-sm">{note}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mb-6">
        <h3 className="text-lg font-semibold mb-2">Macronutrients</h3>
        <div className="h-64 -mx-4">
          <NutritionChart macros={{
            protein: analysis.macronutrients.protein,
            fat: analysis.macronutrients.fat,
            carbs: analysis.macronutrients.carbs
          }} />
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4">
          <div>
            <p className="text-gray-600">Calories</p>
            <p className="font-semibold">{analysis.macronutrients.calories} kcal</p>
          </div>
          <div>
            <p className="text-gray-600">Protein</p>
            <p className="font-semibold">{analysis.macronutrients.protein}g</p>
          </div>
          <div>
            <p className="text-gray-600">Fat</p>
            <p className="font-semibold">{analysis.macronutrients.fat}g</p>
          </div>
          <div>
            <p className="text-gray-600">Carbs</p>
            <p className="font-semibold">{analysis.macronutrients.carbs}g</p>
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-semibold mb-2">Full Ingredients List</h3>
        <ul className="list-disc list-inside grid grid-cols-1 sm:grid-cols-2 gap-2">
          {analysis.ingredients.map((ingredient, index) => (
            <li key={index} className="text-gray-600">{ingredient}</li>
          ))}
        </ul>
      </div>
    </div>
  );
};