export interface FoodAnalysis {
  foodType: string;
  ingredients: string[];
  macronutrients: {
    calories: number;
    protein: number;
    fat: number;
    carbs: number;
  };
  preservatives: string[];
  pregnancySafetyScore: number;
  pregnancySafetyNotes: string;
  allergenInfo: {
    containsGluten: boolean;
    containsPeanuts: boolean;
    containsTreeNuts: boolean;
    containsDairy: boolean;
    containsEggs: boolean;
    containsSoy: boolean;
    containsShellfish: boolean;
    containsFish: boolean;
    otherAllergens: string[];
  };
  allergenNotes: string;
  description?: string;
}